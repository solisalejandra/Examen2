import requests


def leer_archivo():
    try:
        archivo= open("Clientes.txt","r")
        lineas = archivo.readlines()
        val = []
        for linea in lineas:
            nombre, apellido, pais,idioma,aeropuerto = linea.strip().split()
            val.append({"nombre:" nombre, "apellido: "apellido,"pais: "pais,"idioma: "idioma,"aeropuerto: " aeropuerto})
        archivo.close()
        print("Se han insertado los datos")
        return val
    except:
        print("Ha ocurrido un error")

def Peticion():
    try:
        api_url="http://localhost:8080/apiv1/empleados/add"
        response = requests.post(api_url,json=)
        response.json()
        print(response.json())
    except:
        print("Ha ocurrido un error al realizar la operacion")



Peticion()



